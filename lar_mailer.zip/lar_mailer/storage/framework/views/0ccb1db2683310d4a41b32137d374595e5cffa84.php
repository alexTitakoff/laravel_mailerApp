<?php $__env->startSection('content'); ?>



<div class="container">
	<div class="row">

		<div class="col-sm-12">
			<h1>Laravel Mail App</h1>
		</div>

		<div class="col-sm-12">
			<form action="<?php echo e(url('mail/sendmail')); ?>"  method="POST"  class="form-horizontal" role="form" >
				<input type="hidden"  name="_token"  value="<?php echo e(csrf_token()); ?>">
				<div class="form-group">
					<legend>Send an email to anyone </legend>
				</div>


				<div class="form-group">
					<label for="email">Sending to who?</label>
					<input type="email" name="email" value="<?php echo e(Input::old('email')); ?>" class="form-control" placeholder="Type an email"  >
				</div>


				<div class="form-group">
					<label for="subject">Sending to who?</label>
					<input type="subject" name="subject" value="<?php echo e(Input::old('subject')); ?>" class="form-control" placeholder="Subjct"  >
				</div>


				<div class="form-group">
					<label for="message">Your message</label>
					<textarea rows="5" cols="20" id="message" type="text" name="message" value="<?php echo e(Input::old('message')); ?>" class="form-control" placeholder="Type a message"></textarea>
				</div>

				<div class="form-group">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>

			</form>
		</div>
		
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>