## Laravel Mailer App

Laravel Mailer App built using Laravel to demonstrate Laravel's Mail functionality.